function r = DetectWall(robot, a_w, b_w)

x_t = [robot.x robot.y robot.theta]';
r = [];

%Find two points on the wall
x1 = 0;
y1 = a_w*x1 + b_w;

x2 = 1;
y2 = a_w*x2 + b_w;

%There is only one wall in the whole world, so only half the robot will see
%the wall at a time.
for i=1:size(robot.sonar,2)/2

    %Find two points on the sonar line
    x3 = robot.x;
    y3 = robot.y;
    
    x4 = cos(robot.sonar(i))+robot.x;
    y4 = sin(robot.sonar(i))+robot.y;
   
    %Slope and intercept
    a_r = (y3 - y4)/(x3 - x4);
    b_r = y4 - a_r*x4;
        
    %Find intersection
    Px = ((x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4))/((x1-x2)*(y3-y4)-(y1-y2)*(x3-x4));
    Py = ((x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4))/((x1-x2)*(y3-y4)-(y1-y2)*(x3-x4));
    
    %Get the range and the bearing of the measurement from the robot origin
    z_t = get_range_bearing([Px Py]',x_t);
    
    %If the reading is out of range, discard it
    if z_t(1) > 10
       z_t(1) = -1; 
    end
    
    r = [r z_t];
    
end
function rHat = FireSonar(r)

for i=1:size(r,2)
    
    %IS the measurement bad?
    if r(1,i) == -1
       continue; 
    end
    
    %Has the measurement been corrupted by multipath error?
    p_multipath = rand();
    if p_multipath > .75
        %How bad is the error
        p_length = 1.2 + (1.5-1.2).*rand();
        r(1,i) = r(1,i)*p_length;        
    %Otherwise, add some gaussian noise
    else
        r(1,i) = r(1,i)+.01*r(1,i)*randn(1);
    end
    
    %Is this new range greater than 10?
    if r(1,i) > 10
        r(1,i) = -1;
    end
    
end

rHat = r;
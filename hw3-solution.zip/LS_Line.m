function ls_fit_robot = LS_Line(z_t)
    x_t = [0 0 0]';

    %Get all the good measurements
    z_t = z_t(:,z_t(1,:)>-1);

    %Get the position of the points in the robot frame
    wall_robot_frame = get_absolute_location(z_t,x_t);
   
    X = wall_robot_frame(1,:)';
    Y = wall_robot_frame(2,:)';
    
    %Perform the regression
    ls_fit_robot = [ones(length(X),1) X]\Y;
function w = LS_WallFollower(kp,kd,rHat,robot,v)

%Fit a line to the data
ls_fit_robot = LS_Line(rHat);
a_r = ls_fit_robot(2);
b_r = ls_fit_robot(1);

w = get_pd_control(a_r,b_r,kp,kd,robot,v);




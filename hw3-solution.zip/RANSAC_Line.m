function rs_fit_robot=RANSAC_Line(rHat)

x_t = [0 0 0]';


%Get all the good measurements
z_t = rHat(:,rHat(1,:)>-1);

%Number of good points
n = size(z_t,2);

%Get the position of the points in the robot frame
wall_robot_frame = get_absolute_location(z_t,x_t);

%Number of trials before we quit
k=log(1-.999)/log(1-.75^n);
best_fit = 100;
thresh   = 0;
best_a   = 0;
best_b   = 0;
a_w      = 0;
b_w      = 0;

best_consensus_set = [];
best_consensus_count = 0;
for i = 1:k
    %Sample 2 points from the set
    i1 = floor((1-n+1)*rand+n);
    i2 = i1;
    while i2 == i1
        i2 = floor((1-n+1)*rand+n);
    end

    %Our two points
    p1 = wall_robot_frame(:,i1);
    p2 = wall_robot_frame(:,i2);

    %Fit a line through these points using our model
    a_w = (p2(2) - p1(2))/(p2(1) - p1(1));
    b_w = p1(2) - a_w*p1(1);

    
    %Consensus set variables
    consensus_set = [];
    q=1;
    
    %For every point in the good set
    for j = 1:n
       %Calculate the distance to the line
       dist = abs( wall_robot_frame(2,j) - a_w* wall_robot_frame(1,j) - b_w)/sqrt(a_w^2 + 1);
       
       %Determine a threshold
       thresh = .01*z_t(1,j);
       
       %If the distance falls below the threshold, add it to our consesnsus
       %set
       if dist < thresh
           consensus_set(:,q) = z_t(:,j);
           q = q+1;
       end   

    end
    
    %How big is our consensus set?
    m = size(consensus_set,2);
    
    %Determine if our new consensus is better than our old one
    if m > best_consensus_count
       best_consensus_count = m;
       best_consensus_set = consensus_set;
    end

end

%Fit a line to the new data
rs_fit_robot = LS_Line(best_consensus_set);
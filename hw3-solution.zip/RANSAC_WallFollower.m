function w = RANSAC_WallFollower(kp,kd,rHat,robot,v)

%Fit line with RANSAC
rs_fit_robot = RANSAC_Line(rHat);
a_r = rs_fit_robot(2);
b_r = rs_fit_robot(1);

w = get_pd_control(a_r,b_r,kp,kd,robot,v);
function ls_fit_world = Transform_Line(robot, ls_fit_robot)

%Get the robot transform
translation = [robot.x robot.y]';
theta = robot.theta;
rotation    = [cos(theta) -sin(theta); sin(theta) cos(theta)];

%Find two points on the line
x1 = 0;
y1 = ls_fit_robot(2)*x1 + ls_fit_robot(1);
p1 = [x1 y1]';

x2 = 1;
y2 = ls_fit_robot(2)*x2 + ls_fit_robot(1);
p2 = [x2 y2]';

%Transform these points
p1 = rotation*p1 + translation;
p2 = rotation*p2 + translation;

%Find the new line
a_w = (p2(2) - p1(2))/(p2(1) - p1(1));
b_w = p2(2) - a_w*p2(1);

ls_fit_world = [b_w a_w];
    
function s_f=get_absolute_location(z_t,s_t)

%Robot location
x     = s_t(1);
y     = s_t(2);
theta = s_t(3);

%Relative Feature location
rho = z_t(1,:);
phi = z_t(2,:);

%Absolute Feature Location
xf  = x + rho.*cos(phi+theta);
yf  = y + rho.*sin(phi+theta);

s_f = [xf; yf];

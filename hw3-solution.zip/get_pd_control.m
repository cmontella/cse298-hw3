function w = get_pd_control(a_r,b_r,kp,kd,robot,v)

%Find the distance of the robot to the line
wall_dist = abs(b_r)/sqrt(a_r^2 + 1);

%The robot wants to follow 2.5m from the wall
follow_dist = wall_dist - 2.5;

%Find the orientation of the robot w.r.t. the wall
y_wall = b_r/(a_r^2+1);
x_wall = (y_wall-b_r)/a_r;
wall_vec = [x_wall y_wall];
robot_vec = [1 0];

costheta = dot(wall_vec,robot_vec)/(norm(wall_vec)*norm(robot_vec));
wall_orientation = acos(costheta);

%Define the desired wall orientation
desired_orientation = pi/2;

%Error in our pose
ey  = follow_dist;
eth = (desired_orientation - wall_orientation);

%Update the robot with this control
w = (kp*(ey + eth) - kd*tan(robot.theta)/(v*cos(robot.theta)))/(kd + v*cos(robot.theta));
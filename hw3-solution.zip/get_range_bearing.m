%Get range and bearing of measurement given current location
function z_t = get_range_bearing(z_t,x_t)   

dx = z_t(1,:) - x_t(1);
dy = z_t(2,:) - x_t(2);

z_t = [sqrt(dx.^2 + dy.^2); atan2(dy,dx)-x_t(3)];
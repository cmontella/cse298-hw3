function hwk4()
close all; clc; clear;

hold on;
axis([-20 40 -10 10]);

%Define the wall
a_w = 0;
b_w = 2.5;

%Plot the wall
wall = refline(a_w,b_w);
set(wall,'Color','r');

%Plot the wall
wall = refline(0,0);
set(wall,'Color','g');

%Get robot's initial position
%[x,y] = ginput(1);
%theta = -pi/4 + (pi/4+pi/4).*rand();

%Create the robot
robot = make_robot(2,-1.5,-pi/4);
robot.trail = true;

%Robot parameters
linear_velocity = .5;
w = 0;
max_angular_velocity = .5;

%Define our time step
dt = .5;

%points  =  plot(0,0,'b.','erasemode','xor');
while 1;
 

    
    %Get range measurements for the sonar
    r = DetectWall(robot,a_w,b_w);

    %Add noise to the sonar measurements
    rHat = FireSonar(r);
    
    %z = get_absolute_location(rHat,[robot.x robot.y robot.theta]');
    %set(points,'xdata',z(1,:),'ydata',z(2,:));
    
    %Choose controller gains
    kp = 1;
    kd =  2*kp^.5;
    
    %Choose wall following method
    %w = LS_WallFollower(kp,kd,rHat,robot,linear_velocity);
    w = RANSAC_WallFollower(kp,kd,rHat,robot,linear_velocity);
    if abs(w) > max_angular_velocity
        w = sign(w)*max_angular_velocity;
    end
      
    %Plot the lines
    fit_robot = LS_Line(rHat);
    fit_robot = RANSAC_Line(rHat);
    ls_fit_world = Transform_Line(robot,fit_robot);
    wall2 = refline(ls_fit_world(2),ls_fit_world(1));
    set(wall2,'Color','k');
    
    pause(.01);
    delete(wall2);
    
    %Move the robot
    dx = linear_velocity*cos(robot.theta)*dt;
    dy = linear_velocity*sin(robot.theta)*dt;
    dtheta = w*dt;
    robot = move_robot(robot,dx,dy,dtheta,'displacement');
        
end